#ifndef SynthSoundToy_h
#define SynthSoundToy_h

#include "Synth.h"

class SynthSoundToy : public Synth
{
  public:  
    SynthSoundToy(Inputs *inputs); 
};

#endif
