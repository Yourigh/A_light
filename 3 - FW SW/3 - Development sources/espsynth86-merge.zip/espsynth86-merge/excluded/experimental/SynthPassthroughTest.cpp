#include "SynthPassthroughTest.h"

SynthPassthroughTest::SynthPassthroughTest(Inputs* inputs)
{
  this->last_module = inputs->mod;
}

