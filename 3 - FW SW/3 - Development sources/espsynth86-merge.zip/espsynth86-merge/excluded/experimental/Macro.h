#ifndef Macro_h
#define  Macro_h

#include "Module.h"

class Macro : public Module
{
};

#endif