#ifndef SynthPassthroughTest_h
#define SynthPassthroughTest_h

#include "Synth.h"

class SynthPassthroughTest : public Synth
{
  public:
    SynthPassthroughTest(Inputs *inputs); 
};

#endif
