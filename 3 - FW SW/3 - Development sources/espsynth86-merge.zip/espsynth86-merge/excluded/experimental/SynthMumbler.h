#ifndef SynthMumbler_h
#define SynthMumbler_h

#include "Synth.h"

class SynthMumbler : public Synth
{
  public:
    SynthMumbler(Inputs *inputs); 
};

#endif
