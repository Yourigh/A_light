#ifndef SynthPhonetics_h
#define SynthPhonetics_h

#include "Synth.h"

class SynthPhonetics : public Synth
{
  public:
    SynthPhonetics(Inputs *inputs); 
};

#endif