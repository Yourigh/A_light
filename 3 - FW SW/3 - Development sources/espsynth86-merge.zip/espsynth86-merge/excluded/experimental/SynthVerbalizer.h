#ifndef SynthVerbalizer_h
#define SynthVerbalizer_h

#include "Synth.h"

class SynthVerbalizer : public Synth
{
 public:
   SynthVerbalizer(Inputs *inputs);
};

#endif