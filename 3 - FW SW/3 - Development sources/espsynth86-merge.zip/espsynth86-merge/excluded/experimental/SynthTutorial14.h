#ifndef SynthTutorial14_h
#define SynthTutorial14_h

#include "Synth.h"

class SynthTutorial14 : public Synth
{
  public:
    SynthTutorial14(Inputs *inputs); 
};

#endif