// =============================================================================
//
// Name: SynthLooper
// Type: Audio
// Written by: Bret Truchan, 2014
// 
//
// =============================================================================

#ifndef SynthLooper_h
#define SynthLooper_h

#include "Synth.h"

class SynthLooper : public Synth
{
  public:
    SynthLooper(Inputs *inputs); 
};

#endif
