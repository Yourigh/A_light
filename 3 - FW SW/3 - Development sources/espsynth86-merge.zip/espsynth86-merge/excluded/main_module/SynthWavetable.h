// =============================================================================
//
// Name: SynthWavetable
// Type: Audio
// Written by: Bret Truchan, 2014
// 

//
// =============================================================================

#ifndef SynthWavetable_h
#define SynthWavetable_h

#include "Synth.h"

class SynthWavetable : public Synth
{
  public:  
    SynthWavetable(Inputs *inputs); 
};

#endif