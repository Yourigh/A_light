#ifndef SynthAutoDrum_h
#define SynthAutoDrum_h

#include "Synth.h"

class SynthAutoDrum : public Synth
{
  public:
    SynthAutoDrum(Inputs *inputs); 
};

#endif
