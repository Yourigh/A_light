#include "SynthTutorial11.h"

SynthTutorial11::SynthTutorial11(Inputs* inputs)
{

}