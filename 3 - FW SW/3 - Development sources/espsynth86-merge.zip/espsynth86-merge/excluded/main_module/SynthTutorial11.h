// =============================================================================
//
// Name: SynthTutorial11
// Type: Audio
// Written by: Bret Truchan, 2014
// 
// Description: Currently blank
//
// SR  - 
// MOD - 
// [1] - 
// [2] - 
// [3] - 
// GATE - 
//
// =============================================================================

#ifndef SynthTutorial11_h
#define SynthTutorial11_h

#include "Synth.h"

class SynthTutorial11 : public Synth
{
  public:
    SynthTutorial11(Inputs *inputs); 
};

#endif