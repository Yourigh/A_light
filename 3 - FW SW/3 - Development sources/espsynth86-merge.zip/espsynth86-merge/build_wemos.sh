#!/bin/sh
make BOARD=d1_mini
