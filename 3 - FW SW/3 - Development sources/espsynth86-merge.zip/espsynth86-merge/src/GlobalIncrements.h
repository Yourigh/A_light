#ifndef Increments_h
#define Increments_h

extern const uint32_t INCREMENTS[] PROGMEM;

#endif
