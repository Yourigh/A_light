#include "Arduino.h"
#include "Defines.h"
#include "EquationBank.h"

EquationBank::EquationBank()
{
	w = 0;
}