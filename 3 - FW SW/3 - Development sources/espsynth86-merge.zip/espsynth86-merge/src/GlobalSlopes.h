#ifndef Slopes_h
#define Slopes_h

extern const uint8_t SLOPES[][512];

#endif