#include "Arduino.h"
#include "Defines.h"

uint16_t RING_BUFFER[RING_BUFFER_SIZE];
