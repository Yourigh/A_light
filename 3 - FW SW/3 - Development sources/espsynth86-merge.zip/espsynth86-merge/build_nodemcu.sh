#!/bin/sh
make BOARD=nodemcu
