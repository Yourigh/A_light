# ESP8266-12E-Module-Library-For-Eagle
ESP8266-12E-Module-Library-For-Eagle - Here is the ESP8266 12E module's Library file For Eagle. You Can Use This Library For Designing Circuits In Eagle PCB dDesigning CAD software
